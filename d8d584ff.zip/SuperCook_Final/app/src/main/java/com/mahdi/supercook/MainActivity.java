
package com.mahdi.supercook;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView ingredientRecycler;
    private IngredientAdapter adapter;
    private List<String> ingredients = new ArrayList<>();
    private EditText ingredientInput;

    static class IngredientAdapter extends RecyclerView.Adapter<IngredientAdapter.ViewHolder> {
        private List<String> ingredients;
        public IngredientAdapter(List<String> ingredients) { this.ingredients = ingredients; }
        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView textView;
            ViewHolder(View v) { super(v); textView = v.findViewById(android.R.id.text1); }
        }
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_1, parent, false));
        }
        public void onBindViewHolder(ViewHolder holder, int position) {
            holder.textView.setText(ingredients.get(position));
        }
        public int getItemCount() { return ingredients.size(); }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("SuperCook Clone - Mahdi");
        title.setTextSize(24);
        layout.addView(title);

        ingredientInput = new EditText(this);
        ingredientInput.setHint("Ingrédient (oeuf, poulet, tomate...)");
        layout.addView(ingredientInput);

        Button addBtn = new Button(this);
        addBtn.setText("Ajouter placard");
        layout.addView(addBtn);

        TextView pantryLabel = new TextView(this);
        pantryLabel.setText("Placard:");
        pantryLabel.setTextSize(20);
        layout.addView(pantryLabel);

        ingredientRecycler = new RecyclerView(this);
        ingredientRecycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new IngredientAdapter(ingredients);
        ingredientRecycler.setAdapter(adapter);
        layout.addView(ingredientRecycler);

        Button searchBtn = new Button(this);
        searchBtn.setText("Chercher recettes");
        layout.addView(searchBtn);

        setContentView(layout);

        addBtn.setOnClickListener(v -> {
            String ing = ingredientInput.getText().toString().trim();
            if (!ing.isEmpty()) {
                ingredients.add(ing);
                adapter.notifyItemInserted(ingredients.size() - 1);
                ingredientInput.setText("");
                Toast.makeText(this, ing + " ajouté !", Toast.LENGTH_SHORT).show();
            }
        });

        searchBtn.setOnClickListener(v -> searchRecipes());
    }

    private void searchRecipes() {
        if (ingredients.isEmpty()) {
            Toast.makeText(this, "Ajoute des ingrédients d\'abord !", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder result = new StringBuilder("Recettes avec ");
        for (String ing : ingredients) {
            result.append(ing).append(", ");
        }
        result.append("→ ");

        if (ingredients.contains("oeuf")) result.append("Omelette 95%, Quiche 85%");
        else if (ingredients.contains("poulet")) result.append("Poulet rôti 90%, Curry 80%");
        else if (ingredients.contains("tomate")) result.append("Salade 85%, Sauce tomate 95%");
        else result.append("20 recettes possibles");

        Toast.makeText(this, result.toString(), Toast.LENGTH_LONG).show();
    }
}
