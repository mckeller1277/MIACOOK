package com.mahdi.supersimple;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.ViewGroup.LayoutParams;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 50);

        TextView text = new TextView(this);
        text.setText("PantryChef V Super Simple\nCompilation OK !");
        text.setTextSize(20);
        layout.addView(text);

        Button button = new Button(this);
        button.setText("Test");
        layout.addView(button);

        setContentView(layout);
    }
}
